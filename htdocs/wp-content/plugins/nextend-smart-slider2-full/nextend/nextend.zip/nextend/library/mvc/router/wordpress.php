<?php


class NextendRouter extends NextendRouterAbstract{
    
}