<?php

class NextendSmartsliderAdminViewSliders_slider extends NextendView{
    

}
?>
